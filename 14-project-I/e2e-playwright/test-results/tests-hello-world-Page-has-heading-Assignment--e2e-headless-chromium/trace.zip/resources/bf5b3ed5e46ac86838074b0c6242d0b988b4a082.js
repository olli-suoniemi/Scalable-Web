import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Assignments.svelte?svelte&type=style&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/app/src/components/Assignments.svelte?svelte&type=style&lang.css"
const __vite__css = ".spinner.s-ureTDH9cNYq2{border:4px solid rgba(0, 0, 0, 0.1);border-left-color:#000;border-radius:50%;width:24px;height:24px;animation:s-ureTDH9cNYq2-spin 1s linear infinite}@keyframes s-ureTDH9cNYq2-spin{to{transform:rotate(360deg)}}.disabled-grading-button.s-ureTDH9cNYq2{background-color:#cbd5e0;cursor:not-allowed}.s-ureTDH9cNYq2{}"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))
import {
  SvelteComponentDev,
  SvelteComponentTyped,
  afterUpdate,
  beforeUpdate,
  createEventDispatcher,
  getAllContexts,
  getContext,
  hasContext,
  onDestroy,
  onMount,
  setContext,
  tick
} from "/node_modules/.vite/deps/chunk-RVLVW3YK.js?v=4646a0df";
export {
  SvelteComponentDev as SvelteComponent,
  SvelteComponentTyped,
  afterUpdate,
  beforeUpdate,
  createEventDispatcher,
  getAllContexts,
  getContext,
  hasContext,
  onDestroy,
  onMount,
  setContext,
  tick
};
//# sourceMappingURL=svelte.js.map

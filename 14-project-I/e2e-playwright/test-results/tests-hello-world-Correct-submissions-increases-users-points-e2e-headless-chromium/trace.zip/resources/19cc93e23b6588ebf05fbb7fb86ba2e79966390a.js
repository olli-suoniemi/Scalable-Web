import { readable, writable } from "/node_modules/.vite/deps/svelte_store.js?v=4646a0df";

let user = localStorage.getItem("userUuid");

if (!user) {
  user = crypto.randomUUID().toString();
  localStorage.setItem("userUuid", user);
} 

export const userUuid = readable(user);
export const userPoints = writable(0);
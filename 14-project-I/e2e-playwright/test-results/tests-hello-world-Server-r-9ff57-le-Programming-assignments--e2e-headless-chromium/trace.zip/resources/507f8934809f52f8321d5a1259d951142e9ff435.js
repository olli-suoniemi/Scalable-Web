import { makeApplyHmr } from "/node_modules/svelte-hmr/runtime/index.js?v=4646a0df"

export const applyHmr = makeApplyHmr(args =>
  Object.assign({}, args, {
    hot: args.m.hot,
  })
)

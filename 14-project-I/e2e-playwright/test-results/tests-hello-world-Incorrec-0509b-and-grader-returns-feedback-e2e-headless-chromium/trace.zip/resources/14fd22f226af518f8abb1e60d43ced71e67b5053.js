export { makeApplyHmr } from "/node_modules/svelte-hmr/runtime/hot-api.js?v=4646a0df"
